#include "ObjectBwLabel.h"

ObjectBwLabel::ObjectBwLabel()
{

}

